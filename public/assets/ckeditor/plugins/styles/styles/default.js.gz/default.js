/*
Copyright (c) 2003-2011, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.stylesSet.add("default",[{name:"Header 2",element:"h2"},{name:"Header 3",element:"h3"},{name:"Header 4",element:"h4"},{name:"Header 5",element:"h5"},{name:"Inline Quotation",element:"q"}]);